<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
  <symbol id="email" fill="currentColor" viewBox="0 0 16 16">
  <path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555ZM0 4.697v7.104l5.803-3.558L0 4.697ZM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757Zm3.436-.586L16 11.801V4.697l-5.803 3.546Z"/>
  </symbol>
</svg>
<!--
Hello name! You have a scheduled appointment on date time with counsellor. See you there!

Hello name! Counsellor has made a remarks on your wellness check assessment. click here to see

Hello name! Counsellor has made a remarks on your appointment. click here to see

Hello name! Counsellor updated a follow up appointment on your appointment list. click here to see
-->
<div class="row">
    <div class="col-lg-12 col-xlg-12 col-md-12">
        <div class="card">
            <div class="card-body">
            	<div class="row">
            		<div class="col-lg-12 col-xlg-12 col-md-12">
            			<?php
						$query = $this->db->query("SELECT * FROM tblnotification WHERE NotificationTo='".$this->session->userdata('StudentUserID')."' ORDER BY NotificationID DESC;");
						if($query->num_rows()<>0) {
							foreach ($query->result() as $row) :
						?>
						<div class="alert alert-secondary d-flex align-items-center" role="alert">
						  <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#email"/></svg>
						  <div>
						    <?=$row->Notification;?>
						  </div>
						</div>
						<?php
							endforeach;
						} else {
							echo '<p>No notification for now</p>';
						}
            			?>
					</div>
            	</div>
            </div>
        </div>
    </div>
</div>